"""Monthly total-return inputs and point-in-time macro release snapshots."""
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd


@dataclass
class Dataset:
    assets: pd.DataFrame
    factors: pd.DataFrame
    macro: pd.DataFrame
    provenance: dict

    def through(self, date):
        return Dataset(self.assets.loc[:date].copy(), self.factors.loc[:date].copy(),
                       self.macro.loc[:date].copy(), dict(self.provenance))

    def validate(self, minimum=61):
        index = self.assets.index
        if len(index) < minimum:
            raise ValueError(f"Need at least {minimum} consecutive monthly observations")
        expected = pd.date_range(index[0], index[-1], freq="ME")
        if not index.equals(expected):
            raise ValueError("Return dates must be unique consecutive calendar month ends")
        for label, frame in (("assets", self.assets), ("factors", self.factors), ("macro", self.macro)):
            if not frame.index.equals(index) or frame.shape[1] == 0 or not frame.columns.is_unique:
                raise ValueError(f"Invalid {label} alignment or column names")
            if not np.isfinite(frame.to_numpy(dtype=float)).all():
                raise ValueError(f"Missing/nonfinite {label} values; no silent fills or dropped months")
        for frame in (self.assets, self.factors):
            if (frame.to_numpy() <= -1).any():
                raise ValueError("Log-return prototype requires returns > -100%; default/delisting needs explicit handling")


def month_end(value):
    date = pd.Timestamp(value)
    if date.tzinfo is not None or date != date.normalize() or not date.is_month_end:
        raise ValueError("Use a timezone-free calendar month-end date, e.g. 2026-08-31")
    return date


def read_returns(path, cutoff):
    frame = pd.read_csv(path, parse_dates=["date"]).set_index("date").sort_index()
    # Cut off before checking values: future records cannot affect a historical fit.
    frame = frame.loc[:cutoff]
    if frame.columns.empty or not frame.columns.is_unique:
        raise ValueError(f"No valid return columns in {path}")
    return frame.astype(float)


def macro_snapshots(releases, dates, max_age_days=120):
    required = {"series", "observation_date", "available_date", "value"}
    if not required.issubset(releases.columns):
        raise ValueError(f"Macro releases need columns {sorted(required)}")
    records = releases.copy()
    for name in ("observation_date", "available_date"):
        records[name] = pd.to_datetime(records[name])
    records = records[records.available_date <= dates[-1]]
    if records.empty or records[list(required)].isna().any().any():
        raise ValueError("Empty or incomplete macro release ledger")
    if (records.available_date < records.observation_date).any():
        raise ValueError("Macro observations cannot be available before their reference date")
    if records.duplicated(["series", "observation_date", "available_date"]).any():
        raise ValueError("Ambiguous duplicate macro releases")
    names = sorted(records.series.unique())
    rows = []
    for date in dates:
        known = records[(records.available_date <= date) & (records.observation_date <= date)]
        latest = known.sort_values(["observation_date", "available_date"]).groupby("series").tail(1).set_index("series")
        if set(latest.index) != set(names):
            raise ValueError(f"Not all macro states were released by {date.date()}")
        if ((date - latest.observation_date).dt.days > max_age_days).any():
            raise ValueError(f"Stale macro state at {date.date()}")
        rows.append(latest.value.reindex(names).to_numpy(dtype=float))
    return pd.DataFrame(rows, index=dates, columns=names)


def load_dataset(directory, as_of):
    directory, cutoff = Path(directory), month_end(as_of)
    assets = read_returns(directory / "assets.csv", cutoff)
    factors = read_returns(directory / "factors.csv", cutoff)
    if assets.empty or assets.index[-1] != cutoff:
        raise ValueError("Asset data must reach the requested as-of month exactly")
    releases = pd.read_csv(directory / "macro_releases.csv")
    macro = macro_snapshots(releases, assets.index)
    metadata_path = directory / "metadata.json"
    if not metadata_path.exists():
        raise ValueError("metadata.json must declare data_kind, source and return_convention")
    metadata = json.loads(metadata_path.read_text())
    if metadata.get("data_kind") not in ("synthetic", "historical"):
        raise ValueError("metadata.data_kind must be synthetic or historical")
    if metadata.get("return_convention") != "monthly_simple_total_return_decimal" or not metadata.get("source"):
        raise ValueError("Declare source and monthly_simple_total_return_decimal return_convention")
    metadata["input_sha256"] = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                                for name in ("assets.csv", "factors.csv", "macro_releases.csv", "metadata.json")}
    dataset = Dataset(assets, factors, macro, metadata)
    dataset.validate()
    return dataset


def read_scenario(path, dataset, horizon):
    if path is None:
        return None
    frame = pd.read_csv(path, parse_dates=["date"]).set_index("date")
    expected = pd.date_range(dataset.assets.index[-1] + pd.offsets.MonthEnd(), periods=horizon, freq="ME")
    if not frame.index.equals(expected) or set(frame.columns) != set(dataset.macro.columns):
        raise ValueError("Scenario needs every future month and exactly the macro-state columns")
    frame = frame.reindex(columns=dataset.macro.columns).astype(float)
    if not np.isfinite(frame.to_numpy()).all():
        raise ValueError("Scenario contains missing/nonfinite values")
    return frame
