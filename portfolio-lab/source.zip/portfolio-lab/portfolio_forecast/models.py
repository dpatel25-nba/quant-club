"""Small-data candidate models and strictly sequential expert weighting."""
from dataclasses import dataclass
import numpy as np


CANDIDATES = ("historical", "ridge", "nonlinear_ridge")


class Ridge:
    def __init__(self, penalty=1.0, nonlinear=False):
        self.penalty, self.nonlinear = penalty, nonlinear

    def design(self, x):
        z = (np.asarray(x) - self.xmean) / self.xscale
        if self.nonlinear:
            z = np.concatenate((z, np.sqrt(2 / self.omega.shape[1]) * np.cos(z @ self.omega + self.phase)), axis=-1)
        return z

    def fit(self, x, y):
        self.xmean, self.xscale = x.mean(0), np.maximum(x.std(0), 1e-8)
        self.ymean, self.yscale = y.mean(0), np.maximum(y.std(0), 1e-8)
        rng = np.random.default_rng(1701)  # Independent of outcomes and simulation seed.
        self.omega = rng.normal(size=(x.shape[1], 32)) / np.sqrt(x.shape[1])
        self.phase = rng.uniform(0, 2 * np.pi, 32)
        z = self.design(x)
        self.zmean = z.mean(0)
        z = z - self.zmean
        target = (y - self.ymean) / self.yscale
        self.beta = np.linalg.solve(z.T @ z / len(z) + self.penalty * np.eye(z.shape[1]), z.T @ target / len(z))
        return self

    def predict(self, x):
        return self.ymean + (self.design(x) - self.zmean) @ self.beta * self.yscale


class Historical:
    """Shrunken mean for factor log returns; macro states mean revert by 10%."""
    def __init__(self, factor_count):
        self.k = factor_count

    def fit(self, x, y):
        self.factor_mean = .5 * y[:, :self.k].mean(0)
        self.macro_mean = x[:, self.k:].mean(0)
        return self

    def predict(self, x):
        x = np.atleast_2d(x)
        factors = np.broadcast_to(self.factor_mean, (len(x), self.k))
        return np.concatenate((factors, .1 * (self.macro_mean - x[:, self.k:])), axis=1)


def fit_candidate(name, x, y, k):
    if name == "historical":
        return Historical(k).fit(x, y)
    if name not in CANDIDATES:
        raise ValueError(f"Unknown model: {name}")
    return Ridge(penalty=1.0, nonlinear=name == "nonlinear_ridge").fit(x, y)


def supervised(factors, macro):
    state = np.concatenate((factors, macro), axis=1)
    target = np.concatenate((factors[1:], np.diff(macro, axis=0)), axis=1)
    return state[:-1], target, state[-1]


def sequential_weights(x, y, k, minimum=60, validation=48, window=120):
    """Each prediction at j uses labels y[:j], never y[j] or later.

    Exponential expert weights score standardized factor squared error. These
    are not Bayesian posterior probabilities or horizon-calibrated DMA weights.
    """
    logw = np.zeros(len(CANDIDATES))
    archive = []
    for j in range(max(minimum, len(x) - validation), len(x)):
        start = max(0, j - window)
        scale = np.maximum(y[start:j, :k].std(0), 1e-6)
        errors = []
        for name in CANDIDATES:
            model = fit_candidate(name, x[start:j], y[start:j], k)
            prediction = model.predict(x[j:j+1])[0, :k]
            errors.append(float(np.mean(((prediction - y[j, :k]) / scale) ** 2)))
        logw = .98 * logw - .1 * np.asarray(errors)
        logw -= logw.max()
        weights = np.exp(logw) / np.exp(logw).sum()
        weights = .97 * weights + .03 / len(weights)
        logw = np.log(weights)
        archive.append({"origin_row": j, "max_training_target_row": j-1,
                        "loss": dict(zip(CANDIDATES, errors)), "weights": weights.tolist()})
    weights = np.exp(logw - logw.max())
    return weights / weights.sum(), archive


@dataclass
class FittedSystem:
    models: list
    weights: np.ndarray
    state: np.ndarray
    loadings: np.ndarray
    residuals: list
    k: int
    m: int
    archive: list
    state_mean: np.ndarray
    state_scale: np.ndarray


def fit_system(dataset, window=120, minimum=60):
    dataset.validate(minimum + 1)
    f = np.log1p(dataset.factors.to_numpy())
    a = np.log1p(dataset.assets.to_numpy())
    macro = dataset.macro.to_numpy()
    k, m = f.shape[1], macro.shape[1]
    x, y, state = supervised(f, macro)
    weights, archive = sequential_weights(x, y, k, minimum=minimum, window=window)
    start = max(0, len(x) - window)
    x, y = x[start:], y[start:]
    # Asset exposures use contemporaneous factors, not future predictors.
    exposure = Ridge(penalty=.05).fit(f[start+1:], a[start+1:])
    loadings = exposure.beta * exposure.yscale[None, :] / exposure.xscale[:, None]
    asset_residual = a[start+1:] - f[start+1:] @ loadings
    asset_residual -= asset_residual.mean(0)
    # Stock-specific alpha is fixed at zero; no historical alpha extrapolation.
    models = [fit_candidate(name, x, y, k) for name in CANDIDATES]
    residuals = [np.concatenate((y - model.predict(x), asset_residual), axis=1) for model in models]
    return FittedSystem(models, weights, state, loadings, residuals, k, m, archive,
                        x.mean(0), np.maximum(x.std(0), 1e-8))
