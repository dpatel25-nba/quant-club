"""Rolling-origin portfolio distribution evaluation and delayed calibration."""
from dataclasses import replace
import numpy as np
import pandas as pd

from .simulation import simulate, portfolio_paths
from .models import fit_system


def crps(samples, actual):
    """Exact CRPS of the empirical distribution; lower is better."""
    x = np.sort(np.asarray(samples, dtype=float))
    n = len(x)
    return float(np.mean(np.abs(x-actual)) - np.dot(2*np.arange(1, n+1)-n-1, x)/n**2)


def interval_score(lower, upper, actual, alpha=.2):
    return float(upper-lower + 2/alpha*max(lower-actual, 0) + 2/alpha*max(actual-upper, 0))


def interval_adjustment(archive, origin, minimum=20):
    """Empirical rolling correction; not an exchangeability coverage guarantee.

    Only already realized, same-horizon forecast intervals may enter. Scales
    are interval widths and corrections are nonnegative (no interval narrowing).
    """
    mature = [r for r in archive if pd.Timestamp(r["target_end"]) <= pd.Timestamp(origin)]
    if len(mature) < minimum:
        return None
    scores = [max(r["lower"]-r["actual"], r["actual"]-r["upper"], 0) /
              max(r["upper"]-r["lower"], 1e-8) for r in mature[-60:]]
    level = min(1., np.ceil((len(scores)+1)*.8)/len(scores))
    return float(np.quantile(scores, level, method="higher"))


def walk_forward(dataset, weights, config, horizons=(1, 6, 12), step=6,
                 max_origins=24, rebalance="monthly", cost_bps=0.):
    if step < 1 or max_origins < 1 or not horizons or any(not 1 <= h <= 60 for h in horizons):
        raise ValueError("Invalid evaluation origins/horizons")
    rows = []
    dates = dataset.assets.index
    for horizon in horizons:
        eligible = list(range(config.min_train, len(dates)-horizon, step))[-max_origins:]
        archive = []
        for origin in eligible:
            past = dataset.through(dates[origin])
            local_config = replace(config, horizon=horizon, seed=config.seed+origin*101+horizon)
            realized = np.log1p(dataset.assets.iloc[origin+1:origin+horizon+1].to_numpy())[None, :, :]
            actual = float(portfolio_paths(realized, weights, 1., rebalance, cost_bps)[0, -1]-1)
            fitted = fit_system(past, config.window, config.min_train)
            for model in ("block_bootstrap", "historical", "ridge", "nonlinear_ridge", "ensemble"):
                simulation = simulate(past, local_config, model=model, fitted=fitted)
                wealth = portfolio_paths(simulation["asset_log_returns"], weights, 1., rebalance, cost_bps)
                terminal = wealth[:, -1]-1
                lower, upper = np.quantile(terminal, [.1, .9])
                probability = float(np.mean(terminal < 0))
                row = {"origin": str(dates[origin].date()), "target_end": str(dates[origin+horizon].date()),
                       "horizon": horizon, "model": model, "actual": actual,
                       "median": float(np.median(terminal)), "lower": float(lower), "upper": float(upper),
                       "crps": crps(terminal, actual), "interval_score": interval_score(lower, upper, actual),
                       "coverage_80": float(lower <= actual <= upper), "loss_probability": probability,
                       "loss_brier": (probability-float(actual < 0))**2,
                       "pit": float(np.mean(terminal <= actual)),
                       "calibrated_lower": None, "calibrated_upper": None, "calibrated_coverage": None}
                if model == "ensemble":
                    correction = interval_adjustment(archive, dates[origin])
                    if correction is not None:
                        width = upper-lower
                        lo, hi = max(-1., lower-correction*width), upper+correction*width
                        row.update(calibrated_lower=float(lo), calibrated_upper=float(hi),
                                   calibrated_coverage=float(lo <= actual <= hi))
                    archive.append(row.copy())
                rows.append(row)
    if not rows:
        raise ValueError("Not enough history for any held-out evaluation origin")
    frame = pd.DataFrame(rows)
    summary = frame.groupby(["model", "horizon"], as_index=False).agg(
        origins=("crps", "size"), mean_crps=("crps", "mean"),
        coverage_80=("coverage_80", "mean"), mean_interval_score=("interval_score", "mean"),
        loss_brier=("loss_brier", "mean"), calibrated_coverage=("calibrated_coverage", "mean"),
        calibrated_origins=("calibrated_coverage", "count"))
    return frame, summary
