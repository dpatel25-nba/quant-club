"""Run with python -m portfolio_forecast.cli from the standalone project."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import platform

import numpy as np
import pandas as pd

from . import __version__
from .data import load_dataset, read_scenario
from .demo import create_demo
from .evaluation import walk_forward
from .models import fit_system
from .report import write_report
from .simulation import SimulationConfig, simulate, portfolio_paths, summarize


def parse_weights(value, columns):
    if value is None:
        return np.ones(len(columns))/len(columns)
    entries = [part.split("=") for part in value.split(",")]
    if any(len(pair) != 2 for pair in entries) or len({pair[0] for pair in entries}) != len(entries):
        raise ValueError("Weights must be unique TICKER=decimal entries")
    mapping = {name: float(weight) for name, weight in entries}
    if set(mapping) - set(columns):
        raise ValueError("Unknown portfolio ticker")
    result = np.array([mapping.get(name, 0.) for name in columns])
    portfolio_paths(np.zeros((1, 1, len(columns))), result)
    return result


def run(args):
    config = SimulationConfig(horizon=args.horizon, paths=args.paths, seed=args.seed)
    config.validate()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if args.command == "demo":
        args.data = str(create_demo(output/"inputs", horizon=args.horizon))
        args.as_of = "2026-08-31"
        args.scenario = str(Path(args.data)/"scenario.csv")
    dataset = load_dataset(args.data, args.as_of)
    weights = parse_weights(args.weights, dataset.assets.columns)
    portfolio_paths(np.zeros((1, 1, len(weights))), weights, args.initial, args.rebalance, args.cost_bps)
    if args.command == "backtest":
        frame, summary = walk_forward(dataset, weights, config, horizons=tuple(args.horizons),
                                      step=args.step, max_origins=args.max_origins,
                                      rebalance=args.rebalance, cost_bps=args.cost_bps)
        frame.to_csv(output/"backtest.csv", index=False)
        summary.to_csv(output/"backtest_summary.csv", index=False)
        print(summary.to_string(index=False))
        simulations = {}
    else:
        fitted = fit_system(dataset, config.window, config.min_train)
        simulations = {"Baseline outlook": simulate(dataset, config, fitted=fitted)}
        if args.scenario:
            scenario = read_scenario(args.scenario, dataset, config.horizon)
            simulations["User macro scenario"] = simulate(dataset, config, scenario=scenario, fitted=fitted)
            scenario.to_csv(output/"scenario_used.csv", index_label="date")
        results = {}
        for i, (name, result) in enumerate(simulations.items()):
            wealth = portfolio_paths(result["asset_log_returns"], weights, args.initial, args.rebalance, args.cost_bps)
            results[name] = {"summary": summarize(wealth), "diagnostics": result["diagnostics"]}
            np.savez_compressed(output/f"paths_{i}.npz", **{k: v for k, v in result.items() if isinstance(v, np.ndarray)}, wealth=wealth)
        (output/"forecast.json").write_text(json.dumps(results, indent=2, allow_nan=False)+"\n")
        write_report(output/"report.html", dataset, simulations, config, weights.tolist(), args.initial, args.rebalance, args.cost_bps)
        print(f"Created {output / 'report.html'} ({dataset.provenance['data_kind']} inputs; unvalidated research)")
    source = Path(__file__).parent
    manifest = {"version": __version__, "command": args.command, "as_of": args.as_of,
                "config": asdict(config), "assets": list(dataset.assets.columns), "factors": list(dataset.factors.columns),
                "macro_states": list(dataset.macro.columns), "weights": weights.tolist(), "initial": args.initial,
                "rebalance": args.rebalance, "cost_bps_per_one_way_turnover": args.cost_bps,
                "data": dataset.provenance, "python": platform.python_version(),
                "numpy": np.__version__, "pandas": pd.__version__,
                "scenario_sha256": hashlib.sha256(Path(args.scenario).read_bytes()).hexdigest() if getattr(args, "scenario", None) else None,
                "evaluation": {key: getattr(args, key) for key in ("horizons", "step", "max_origins")} if args.command == "backtest" else None,
                "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.iterdir()) if p.suffix in (".py", ".html")},
                "limitations": ["No demonstrated real-market predictive skill", "Fixed present-day holdings are not a historical trading strategy",
                                "Macro scenarios have no estimated occurrence probability", "No exact default/delisting, taxes, or intramonth drawdowns",
                                "Finite historical shock support; no full parameter posterior", "Monthly market return availability assumed at month end"]}
    name = "backtest_manifest.json" if args.command == "backtest" else "manifest.json"
    (output/name).write_text(json.dumps(manifest, indent=2, allow_nan=False)+"\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("demo", "run", "backtest"):
        sub = commands.add_parser(command)
        if command != "demo":
            sub.add_argument("--data", required=True)
            sub.add_argument("--as-of", required=True)
        sub.add_argument("--output", default="outputs/"+command)
        sub.add_argument("--paths", type=int, default=1200 if command == "demo" else 3000)
        sub.add_argument("--horizon", type=int, default=12)
        sub.add_argument("--seed", type=int, default=42)
        sub.add_argument("--weights", help="Comma-separated TICKER=decimal; defaults to equal weight")
        sub.add_argument("--initial", type=float, default=10000.)
        sub.add_argument("--rebalance", choices=("monthly", "buy_hold"), default="monthly")
        sub.add_argument("--cost-bps", type=float, default=0.)
        if command != "backtest":
            sub.add_argument("--scenario")
        else:
            sub.add_argument("--horizons", type=int, nargs="+", default=[1, 6, 12])
            sub.add_argument("--step", type=int, default=6)
            sub.add_argument("--max-origins", type=int, default=24)
    args = parser.parse_args()
    try:
        run(args)
    except (ValueError, FileNotFoundError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
