"""Research models, not validated investment forecasts."""

__version__ = "0.1.0"
