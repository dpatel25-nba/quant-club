"""An offline interactive portfolio builder; no external scripts or services."""
from pathlib import Path
import json
import numpy as np


def write_report(path, dataset, simulations, config, weights, initial, rebalance, cost_bps):
    data = {"assets": list(dataset.assets.columns), "factors": list(dataset.factors.columns),
            "asOf": str(dataset.assets.index[-1].date()), "kind": dataset.provenance["data_kind"],
            "paths": config.paths, "horizon": config.horizon, "weights": list(weights),
            "initial": initial, "rebalance": rebalance, "costBps": cost_bps, "runs": {}}
    for name, simulation in simulations.items():
        data["runs"][name] = {"assets": np.round(simulation["asset_log_returns"], 8).tolist(),
                               "benchmark": np.round(simulation["factor_log_returns"][:, :, 0], 8).tolist(),
                               "diagnostics": simulation["diagnostics"]}
    # Defend script contexts even for user-provided ticker/scenario strings.
    payload = json.dumps(data, separators=(",", ":"), allow_nan=False).replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    template = Path(__file__).with_name("report.html").read_text()
    Path(path).write_text(template.replace("__FORECAST_DATA__", payload))
