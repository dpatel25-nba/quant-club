"""Joint filtered block bootstrap and explicit self-financing portfolios."""
from dataclasses import dataclass
import numpy as np
import pandas as pd

from .models import CANDIDATES, fit_system


@dataclass(frozen=True)
class SimulationConfig:
    horizon: int = 12
    paths: int = 3000
    seed: int = 42
    window: int = 120
    min_train: int = 60
    ewma_decay: float = .94
    block_length: float = 3.0
    correlation_shrinkage: float = .1

    def validate(self):
        for name in ("horizon", "paths", "window", "min_train", "seed"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool):
                raise ValueError(f"{name} must be an integer")
        if not 1 <= self.horizon <= 60 or not 100 <= self.paths <= 50000:
            raise ValueError("Use 1–60 months and 100–50,000 paths")
        if self.min_train < 24 or self.window < self.min_train or self.seed < 0:
            raise ValueError("Invalid training window, minimum history, or seed")
        if not 0 < self.ewma_decay < 1 or not np.isfinite(self.block_length) or self.block_length < 1:
            raise ValueError("Invalid volatility decay or block length")
        if not 0 <= self.correlation_shrinkage <= 1:
            raise ValueError("Invalid correlation shrinkage")


def filtered_residuals(residual, decay):
    residual = residual - residual.mean(0)
    floor = np.maximum(.01 * np.mean(residual ** 2, axis=0), 1e-12)
    variance = np.maximum(np.mean(residual[:min(12, len(residual))] ** 2, axis=0), floor)
    standardized = []
    for row in residual:
        standardized.append(row / np.sqrt(variance))
        variance = np.maximum(decay * variance + (1-decay) * row ** 2, floor)
    z = np.asarray(standardized)
    z -= z.mean(0)
    z /= np.maximum(z.std(0), 1e-8)
    return z, variance, floor


def simulate(dataset, config=SimulationConfig(), scenario=None, model="ensemble", fitted=None):
    config.validate()
    dataset.validate(config.min_train + 1)
    if model not in ("ensemble", "block_bootstrap") + CANDIDATES:
        raise ValueError("Unknown simulation model")
    if scenario is not None:
        expected = pd.date_range(dataset.assets.index[-1] + pd.offsets.MonthEnd(),
                                 periods=config.horizon, freq="ME")
        if (not scenario.index.equals(expected) or not scenario.columns.equals(dataset.macro.columns)
                or not np.isfinite(scenario.to_numpy()).all()):
            raise ValueError("Scenario dates/columns must match the complete future macro path")
        if model == "block_bootstrap":
            raise ValueError("Unconditional block benchmark does not support macro scenarios")
    rng = np.random.default_rng(config.seed)
    n, h, asset_count = config.paths, config.horizon, dataset.assets.shape[1]
    if model == "block_bootstrap":
        historical = np.log1p(np.concatenate((dataset.assets.to_numpy(), dataset.factors.to_numpy()), axis=1))[-config.window:]
        idx = rng.integers(len(historical), size=n)
        draws = np.empty((n, h, historical.shape[1]))
        for step in range(h):
            if step:
                restart = rng.random(n) < 1 / config.block_length
                idx = np.where(restart, rng.integers(len(historical), size=n), (idx+1) % len(historical))
            draws[:, step] = historical[idx]
        return {"asset_log_returns": draws[:, :, :asset_count], "factor_log_returns": draws[:, :, asset_count:],
                "diagnostics": {"model": model, "weights": {}, "scenario": False, "extrapolation_fraction": 0.0}}
    fitted = fitted if fitted is not None else fit_system(dataset, config.window, config.min_train)
    weights = fitted.weights if model == "ensemble" else np.eye(len(CANDIDATES))[CANDIDATES.index(model)]
    # One expert per whole path: retain between-model uncertainty over the horizon.
    choices = rng.choice(len(weights), size=n, p=weights)
    asset_paths = np.empty((n, h, asset_count))
    factor_paths = np.empty((n, h, fitted.k))
    macro_paths = np.empty((n, h, fitted.m))
    extrapolations = 0
    k, m = fitted.k, fitted.m
    for expert, mean_model in enumerate(fitted.models):
        selected = np.flatnonzero(choices == expert)
        size = len(selected)
        if not size:
            continue
        z, var, floor = filtered_residuals(fitted.residuals[expert], config.ewma_decay)
        variance = np.broadcast_to(var, (size, len(var))).copy()
        state = np.broadcast_to(fitted.state, (size, len(fitted.state))).copy()
        idx = rng.integers(len(z), size=size)
        shrink = config.correlation_shrinkage
        # Covariance of the sampled innovation after diagonal shrinkage.
        corr = z.T @ z / len(z)
        corr = (1-shrink) * corr + shrink * np.diag(np.diag(corr))
        other = np.r_[0:k, k+m:len(var)]
        # Linear conditional projection, not an exact non-Gaussian conditional law.
        projection = np.linalg.solve(corr[k:k+m, k:k+m] + 1e-8*np.eye(m), corr[k:k+m][:, other])
        for step in range(h):
            extrapolations += int(np.any(np.abs((state-fitted.state_mean)/fitted.state_scale) > 5, axis=1).sum())
            if step:
                restart = rng.random(size) < 1/config.block_length
                idx = np.where(restart, rng.integers(len(z), size=size), (idx+1) % len(z))
            independent = z[rng.integers(len(z), size=(size, len(var))), np.arange(len(var))]
            innovation = np.sqrt(1-shrink)*z[idx] + np.sqrt(shrink)*independent
            prediction = mean_model.predict(state)
            if scenario is not None:
                macro_next = np.broadcast_to(scenario.iloc[step].to_numpy(), (size, m))
                forced = (macro_next - state[:, k:] - prediction[:, k:]) / np.sqrt(variance[:, k:k+m])
                innovation[:, other] += (forced-innovation[:, k:k+m]) @ projection
                innovation[:, k:k+m] = forced
            shock = innovation * np.sqrt(variance)
            factor_next = prediction[:, :k] + shock[:, :k]
            macro_next = state[:, k:] + prediction[:, k:] + shock[:, k:k+m]
            asset_next = factor_next @ fitted.loadings + shock[:, k+m:]
            if not np.isfinite(asset_next).all() or np.max(np.abs(asset_next)) > 20:
                raise ValueError("Unstable simulated returns; inspect scenario/model rather than silently clipping paths")
            asset_paths[selected, step] = asset_next
            factor_paths[selected, step] = factor_next
            macro_paths[selected, step] = macro_next
            variance = np.maximum(config.ewma_decay*variance + (1-config.ewma_decay)*shock**2, floor)
            state = np.concatenate((factor_next, macro_next), axis=1)
    return {"asset_log_returns": asset_paths, "factor_log_returns": factor_paths, "macro_states": macro_paths,
            "diagnostics": {"model": model, "weights": dict(zip(CANDIDATES, weights.tolist())),
                            "scenario": scenario is not None, "weight_validation_months": len(fitted.archive),
                            "extrapolation_fraction": extrapolations/(n*h),
                            "loadings": fitted.loadings.tolist(), "weight_archive": fitted.archive}}


def portfolio_paths(log_returns, weights, initial=10000., rebalance="monthly", cost_bps=0.):
    values = np.asarray(log_returns, dtype=float)
    weights = np.asarray(weights, dtype=float)
    if values.ndim != 3 or not np.isfinite(values).all() or weights.shape != (values.shape[2],):
        raise ValueError("Invalid paths or portfolio dimensions")
    if not np.isfinite(weights).all() or (weights < 0).any() or not np.isclose(weights.sum(), 1, atol=1e-10, rtol=0):
        raise ValueError("Long-only weights must be finite and sum to one")
    if not np.isfinite(initial) or initial <= 0 or not np.isfinite(cost_bps) or not 0 <= cost_bps < 10000:
        raise ValueError("Invalid starting value or transaction cost")
    if rebalance not in ("monthly", "buy_hold"):
        raise ValueError("Rebalance must be monthly or buy_hold")
    holdings = np.broadcast_to(initial*weights, (len(values), len(weights))).copy()
    wealth = np.full((len(values), values.shape[1]+1), initial)
    for step in range(values.shape[1]):
        holdings *= np.exp(values[:, step])
        total = holdings.sum(1)
        # No artificial trade at terminal liquidation; opening allocation is pre-existing.
        if rebalance == "monthly" and step < values.shape[1]-1:
            current = holdings / total[:, None]
            turnover = .5*np.abs(current-weights).sum(1)
            total *= 1 - cost_bps/10000*turnover
            holdings = total[:, None]*weights
        wealth[:, step+1] = total
    if not np.isfinite(wealth).all():
        raise ValueError("Nonfinite simulated wealth")
    return wealth


def summarize(wealth):
    returns = wealth[:, -1]/wealth[:, 0]-1
    quantiles = np.quantile(returns, [.05, .1, .5, .9, .95])
    drawdowns = np.max(1-wealth/np.maximum.accumulate(wealth, axis=1), axis=1)
    return {"median_return": float(quantiles[2]), "mean_return": float(returns.mean()),
            "return_p05": float(quantiles[0]), "return_p10": float(quantiles[1]),
            "return_p90": float(quantiles[3]), "return_p95": float(quantiles[4]),
            "loss_probability": float(np.mean(returns < 0)),
            "worst_5pct_mean_return": float(returns[returns <= quantiles[0]].mean()),
            "median_max_drawdown": float(np.median(drawdowns)),
            "p95_max_drawdown": float(np.quantile(drawdowns, .95)),
            "value_quantiles": np.quantile(wealth, [.1, .5, .9], axis=0).tolist()}
