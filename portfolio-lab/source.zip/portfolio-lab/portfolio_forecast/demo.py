"""Fabricated data for software demonstration, never market evidence."""
from pathlib import Path
import json
import numpy as np
import pandas as pd


def create_demo(directory, months=300, seed=20260923, horizon=12):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    dates = pd.date_range(end="2026-08-31", periods=months, freq="ME")
    macro = np.zeros((months, 3))
    factors = np.zeros((months, 2))
    assets = np.zeros((months, 4))
    beta = np.array([[1.2, .85, .6, 1.05], [.2, .6, .9, -.15]])
    level = np.array([2., 2.5, 3.])
    stress = False
    for t in range(months):
        if rng.random() < (.16 if stress else .035):
            stress = not stress
        shock = rng.normal(size=9)
        macro[t] = .85*(macro[t-1] if t else np.zeros(3)) + .25*shock[:3]
        lag = macro[t-1] if t else np.zeros(3)
        risk = .055 if stress else .025
        factors[t] = np.array([.004+.005*lag[0]-.004*lag[1], .003-.003*lag[2]]) + risk*shock[3:5]
        factors[t, 0] += .008*shock[0]
        assets[t] = factors[t] @ beta + (.012 if not stress else .03)*shock[5:]
    pd.DataFrame(np.expm1(assets), index=dates, columns=["DEMO_GROWTH", "DEMO_BROAD", "DEMO_DEFENSIVE", "DEMO_CYCLICAL"]).rename_axis("date").to_csv(directory/"assets.csv")
    pd.DataFrame(np.expm1(factors), index=dates, columns=["DEMO_MARKET", "DEMO_QUALITY"]).rename_axis("date").to_csv(directory/"factors.csv")
    names = ["growth", "inflation", "policy_rate"]
    releases = []
    for t, date in enumerate(dates):
        for j, name in enumerate(names):
            releases.append({"series": name, "observation_date": str((date-pd.offsets.MonthEnd()).date()),
                             "available_date": str(date.date()), "value": macro[t, j]+level[j]})
    pd.DataFrame(releases).to_csv(directory/"macro_releases.csv", index=False)
    scenario_dates = pd.date_range(dates[-1]+pd.offsets.MonthEnd(), periods=horizon, freq="ME")
    path = macro[-1]+level+np.linspace(1/horizon, 1, horizon)[:, None]*np.array([-1.5, 1., .75])
    pd.DataFrame(path, index=scenario_dates, columns=names).rename_axis("date").to_csv(directory/"scenario.csv")
    metadata = {"data_kind": "synthetic", "source": "Fabricated correlated macro/factor process; no real securities",
                "return_convention": "monthly_simple_total_return_decimal", "seed": seed,
                "macro_units": {"growth": "percentage points", "inflation": "percentage points", "policy_rate": "percentage points"}}
    (directory/"metadata.json").write_text(json.dumps(metadata, indent=2)+"\n")
    return directory
