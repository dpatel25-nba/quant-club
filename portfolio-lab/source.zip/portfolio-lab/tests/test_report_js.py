"""Execute report JavaScript and reconcile accounting with Python.

Uses Node or macOS JavaScriptCore when present. A minimal DOM exercises the
actual report's event handler; this does not claim browser layout validation.
"""
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

import numpy as np

from portfolio_forecast.data import load_dataset
from portfolio_forecast.demo import create_demo
from portfolio_forecast.report import write_report
from portfolio_forecast.simulation import SimulationConfig, portfolio_paths, simulate, summarize


JSC = "/System/Library/Frameworks/JavaScriptCore.framework/Versions/A/Helpers/jsc"
RUNTIME = shutil.which("node") or (JSC if Path(JSC).exists() else None)


@unittest.skipUnless(RUNTIME, "JavaScript runtime not installed")
class ReportJavaScriptTests(unittest.TestCase):
    def test_controls_and_accounting_match_python(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = create_demo(tmp, months=100)
            data = load_dataset(directory, "2026-08-31")
            config = SimulationConfig(paths=200, horizon=3)
            simulation = simulate(data, config)
            report = Path(tmp)/"report.html"
            write_report(report, data, {"Baseline": simulation}, config, [.25]*4, 10000., "monthly", 10.)
            html = report.read_text()
            payload = re.search(r'<script id="forecast-data" type="application/json">(.*?)</script>', html, re.S).group(1)
            code = re.findall(r"<script>(.*?)</script>", html, re.S)[0]
            mock = r'''
const elements = {};
class Element {
 constructor(){this.children=[];this.value='';this._text='';this.innerHTML='';}
 set textContent(v){this._text=String(v);this.children=[];}
 get textContent(){return this._text;}
 append(...nodes){for(const n of nodes){this.children.push(n);if(n.id)elements[n.id]=n;if(!this.value&&n.value)this.value=n.value;}}
 setAttribute(){}
 addEventListener(name, callback){this.handler=callback;}
}
const document={getElementById(id){return elements[id]||(elements[id]=new Element());},createElement(){return new Element();}};
'''
            prefix = "function print(x){console.log(x);}\n" if "node" in Path(RUNTIME).name else ""
            # JSON string encoding, not shell interpolation.
            script = prefix+mock+"\ndocument.getElementById('forecast-data').textContent="+json.dumps(payload)+";\n"+code+r'''
const initialError=$('error').textContent;
const comparison=[];
for(const mode of ['monthly','buy_hold']){
 for(const horizon of [1,3]){
  const paths=wealth(D.runs.Baseline.assets,[.1,.2,.3,.4],12000,horizon,mode,15);
  comparison.push({mode,horizon,last:paths.map(p=>p[p.length-1])});
 }
}
$('w0').value='-1';$('update').handler();
const invalidError=$('error').textContent;
$('w0').value='25';$('horizon').value='2';$('rebalance').value='buy_hold';$('update').handler();
print(JSON.stringify({initialError,invalidError,restoredError:$('error').textContent,comparison,value:$('value').textContent,chart:$('fan').innerHTML.length}));
'''
            path = Path(tmp)/"check.js"
            path.write_text(script)
            run = subprocess.run([RUNTIME, str(path)], capture_output=True, text=True, check=True)
            result = json.loads(run.stdout)
            self.assertEqual(result["initialError"], "")
            self.assertIn("Weights", result["invalidError"])
            self.assertEqual(result["restoredError"], "")
            self.assertGreater(result["chart"], 100)
            for comparison in result["comparison"]:
                paths = portfolio_paths(np.round(simulation["asset_log_returns"][:, :comparison["horizon"]], 8),
                                        [.1, .2, .3, .4], 12000., comparison["mode"], 15.)
                np.testing.assert_allclose(comparison["last"], paths[:, -1], atol=1e-8, rtol=1e-12)


if __name__ == "__main__":
    unittest.main()
