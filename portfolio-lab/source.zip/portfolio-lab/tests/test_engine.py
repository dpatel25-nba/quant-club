import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd

from portfolio_forecast.data import Dataset, load_dataset, macro_snapshots, read_scenario
from portfolio_forecast.demo import create_demo
from portfolio_forecast.evaluation import crps, interval_adjustment, walk_forward
from portfolio_forecast.models import Ridge, fit_system, sequential_weights, supervised
from portfolio_forecast.report import write_report
from portfolio_forecast.simulation import SimulationConfig, portfolio_paths, simulate, summarize


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = create_demo(cls.temp.name, months=110)
        cls.data = load_dataset(cls.root, "2026-08-31")
        cls.config = SimulationConfig(horizon=3, paths=200, seed=10)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_release_dates_and_revisions(self):
        ledger = pd.DataFrame([
            ["growth", "2020-01-31", "2020-02-15", 1.],
            ["growth", "2020-01-31", "2020-04-15", 99.],
            ["growth", "2020-02-29", "2020-03-15", 2.],
        ], columns=["series", "observation_date", "available_date", "value"])
        snapshots = macro_snapshots(ledger, pd.date_range("2020-02-29", periods=3, freq="ME"))
        np.testing.assert_array_equal(snapshots.growth, [1., 2., 2.])
        with self.assertRaises(ValueError):
            macro_snapshots(ledger, pd.date_range("2021-01-31", periods=1, freq="ME"))

    def test_future_poisoning_full_pipeline(self):
        cutoff = self.data.assets.index[85]
        clean = self.data.through(cutoff)
        poisoned = Dataset(self.data.assets.copy(), self.data.factors.copy(), self.data.macro.copy(), self.data.provenance)
        for frame in (poisoned.assets, poisoned.factors, poisoned.macro):
            frame.loc[frame.index > cutoff] = 1e20
        expected = simulate(clean, self.config)
        actual = simulate(poisoned.through(cutoff), self.config)
        np.testing.assert_array_equal(expected["asset_log_returns"], actual["asset_log_returns"])
        self.assertEqual(expected["diagnostics"], actual["diagnostics"])

    def test_archived_weight_update_ignores_later_targets(self):
        f = np.log1p(self.data.factors.to_numpy())
        x, y, _ = supervised(f, self.data.macro.to_numpy())
        _, archive = sequential_weights(x, y, 2, validation=100)
        poisoned = y.copy()
        poisoned[80:] = 1e12
        _, alternate = sequential_weights(x, poisoned, 2, validation=100)
        for clean, poisoned_row in zip(archive[:20], alternate[:20]):
            np.testing.assert_allclose(clean["weights"], poisoned_row["weights"], atol=1e-12, rtol=1e-12)
            np.testing.assert_allclose(list(clean["loss"].values()), list(poisoned_row["loss"].values()), atol=1e-12, rtol=1e-12)
        self.assertTrue(all(row["max_training_target_row"] < row["origin_row"] for row in archive))

    def test_training_only_scaling(self):
        rng = np.random.default_rng(12)
        x = rng.normal(size=(200, 2))
        beta = np.array([[.4], [-.2]])
        model = Ridge(penalty=1e-8).fit(x, x @ beta + 3.)
        np.testing.assert_allclose(model.predict(x), x@beta+3., atol=1e-7)
        mean = model.xmean.copy()
        model.predict(np.array([[1e9, -1e9]]))
        np.testing.assert_array_equal(mean, model.xmean)

    def test_self_financing_and_drawdown(self):
        r = np.log1p(np.array([[[.1, -.1], [-.1, .1]]]))
        hold = portfolio_paths(r, [.5, .5], 100., "buy_hold")
        monthly = portfolio_paths(r, [.5, .5], 100., "monthly")
        np.testing.assert_allclose(hold, [[100, 100, 99]])
        np.testing.assert_allclose(monthly, [[100, 100, 100]])
        cost = portfolio_paths(r, [.5, .5], 100., "monthly", 100.)
        np.testing.assert_allclose(cost, [[100, 99.95, 99.95]])
        loss = summarize(np.array([[100., 80., 90.]]))
        self.assertAlmostEqual(loss["median_max_drawdown"], .2)
        self.assertEqual(loss["loss_probability"], 1.)

    def test_correlated_assets_not_independent(self):
        # Duplicate an asset: independent simulation would falsely create diversification.
        assets = self.data.assets[[self.data.assets.columns[0]]].copy()
        assets["IDENTICAL"] = assets.iloc[:, 0]
        duplicate = Dataset(assets, self.data.factors, self.data.macro, self.data.provenance)
        config = SimulationConfig(horizon=1, paths=1000, correlation_shrinkage=0.)
        sim = simulate(duplicate, config)
        np.testing.assert_allclose(sim["asset_log_returns"][:, :, 0], sim["asset_log_returns"][:, :, 1], atol=1e-10)

    def test_reproducibility_and_scenario_conditioning(self):
        first = simulate(self.data, self.config)
        second = simulate(self.data, self.config)
        np.testing.assert_array_equal(first["asset_log_returns"], second["asset_log_returns"])
        future = pd.date_range("2026-09-30", periods=3, freq="ME")
        scenario = pd.DataFrame(np.tile(self.data.macro.iloc[-1].to_numpy(), (3, 1)), index=future, columns=self.data.macro.columns)
        scenario.iloc[:, 0] -= .5
        conditional = simulate(self.data, self.config, scenario=scenario)
        np.testing.assert_allclose(conditional["macro_states"], np.broadcast_to(scenario.to_numpy(), (200, 3, 3)), atol=1e-10)
        self.assertFalse(np.array_equal(first["asset_log_returns"], conditional["asset_log_returns"]))
        self.assertAlmostEqual(sum(first["diagnostics"]["weights"].values()), 1.)

    def test_crps_matches_pairwise_definition(self):
        samples = np.array([-.1, 0, .05, .2])
        actual = .04
        expected = np.abs(samples-actual).mean()-.5*np.abs(samples[:, None]-samples).mean()
        self.assertAlmostEqual(crps(samples, actual), expected)

    def test_calibration_requires_mature_outcomes(self):
        record = {"target_end": "2025-12-31", "lower": -.1, "upper": .1, "actual": .3}
        archive = [record.copy() for _ in range(20)]
        self.assertIsNone(interval_adjustment(archive, "2025-11-30"))
        self.assertAlmostEqual(interval_adjustment(archive, "2025-12-31"), 1.)
        archive += [{**record, "target_end": "2027-12-31", "actual": 999}]
        self.assertAlmostEqual(interval_adjustment(archive, "2025-12-31"), 1.)

    def test_bad_inputs_fail(self):
        for weights in ([.5, -.5], [.3, .3], [np.nan, 1]):
            with self.assertRaises(ValueError):
                portfolio_paths(np.zeros((1, 2, 2)), weights)
        broken = self.data.through(self.data.assets.index[-1])
        broken.assets.iloc[0, 0] = -1
        with self.assertRaises(ValueError):
            broken.validate()
        broken = self.data.through(self.data.assets.index[-1])
        broken.assets = broken.assets.drop(broken.assets.index[10])
        with self.assertRaises(ValueError):
            broken.validate()
        with self.assertRaises(ValueError):
            SimulationConfig(paths=10).validate()

    def test_walk_forward_scores_all_candidates(self):
        records, summary = walk_forward(self.data, np.ones(4)/4, self.config, horizons=(1, 3), max_origins=2, step=12)
        self.assertEqual(len(records), 20)
        self.assertEqual(len(summary), 10)
        self.assertTrue(np.isfinite(records.crps).all())
        self.assertTrue((pd.to_datetime(records.origin) < pd.to_datetime(records.target_end)).all())
        self.assertTrue(records.calibrated_lower.isna().all())

    def test_report_escapes_script_data(self):
        dataset = self.data.through(self.data.assets.index[-1])
        dataset.assets.columns = ['</script><script>alert(1)</script>', 'B', 'C', 'D']
        result = simulate(dataset, self.config)
        output = Path(self.temp.name)/"test.html"
        write_report(output, dataset, {"Baseline": result}, self.config, [.25]*4, 10000, "monthly", 0.)
        html = output.read_text()
        self.assertNotIn('</script><script>alert(1)</script>', html)
        self.assertIn('\\u003c/script>', html)
        self.assertNotIn('__FORECAST_DATA__', html)


if __name__ == "__main__":
    unittest.main()
