# Portfolio Lab

A standalone portfolio forecasting and scenario-simulation research project.
It has no dependency on the parent style-rotation scripts, data, or website.
The folder can be copied into a separate repository.

**Status: working prototype, not a validated stock-return forecasting system.**
The included demonstration uses fabricated assets and macro histories. No
real-market predictive performance has been established. No pretrained neural
model is installed, downloaded, or secretly represented by a simpler model.

## Try the interactive demo

From this folder, using the existing workspace environment:

```sh
../venv/bin/python -m portfolio_forecast.cli demo --output outputs/demo --paths 1500 --cost-bps 10
open outputs/demo/report.html
```

Or install independently with Python 3.9+:

```sh
python -m venv .venv
.venv/bin/python -m pip install -e .
.venv/bin/python -m portfolio_forecast.cli demo
```

The report works offline. Change holdings' weights, starting value, horizon,
rebalancing and trading-cost assumptions. Compare the baseline with a specified
macro path. The browser revalues the same joint asset paths; it does not refit
the forecasting models. The default benchmark is the first factor column.
All demo names beginning `DEMO_` are fabricated, not real ticker symbols.

## What's implemented

- Point-in-time macro snapshots from a release/revision ledger, with stale-data
  rejection and no silent filling of missing return months.
- Regularized asset factor exposures and zero stock-specific alpha.
- Three small-data mean models: shrunken historical factor means, macro/factor
  ridge regression, and a nonlinear random-Fourier-feature ridge model.
- Online expert weights computed from earlier one-month forecast errors.
- Joint filtered stationary-block bootstrap innovations, EWMA volatility,
  diagonal correlation shrinkage and one expert sampled per complete path.
- Baseline macro/factor simulation and approximate linear conditioning on
  specified macro-state paths. Scenario probabilities are not estimated.
- Buy-and-hold and monthly-rebalanced portfolio accounting, transaction-cost
  assumptions, percentile paths, loss frequencies and monthly drawdowns.
- A joint historical block-bootstrap benchmark and chronological comparisons
  of all three candidates and the ensemble at 1/6/12 months.
- CRPS, interval score, empirical coverage, loss Brier score and PIT exports.
  A separate rolling interval correction uses only matured same-horizon errors;
  it is diagnostic and does not calibrate live paths or loss probabilities.
- Reproducible seeds, input/source hashes, full-precision path artifacts and
  an offline interactive report.

Read [the research review](docs/RESEARCH.md) for current techniques and evidence,
[the exact model specification](docs/MODEL_SPEC.md) for assumptions, and
[the development roadmap](docs/ROADMAP.md) for the remaining work. The
[verification record](docs/VALIDATION.md) reports software checks and the
synthetic benchmark results, including the ensemble's failure to beat the
historical bootstrap on mean CRPS in this run.

## Bring historical data

See [DATA_CONTRACT.md](docs/DATA_CONTRACT.md). Required files are `assets.csv`,
`factors.csv`, `macro_releases.csv` and `metadata.json`. Generated demo inputs
under `outputs/demo/inputs/` provide runnable schema examples.

```sh
../venv/bin/python -m portfolio_forecast.cli run \
  --data /path/to/data --as-of 2026-08-31 \
  --weights 'AAPL=0.25,MSFT=0.25,SPY=0.5' \
  --horizon 12 --paths 5000 --initial 10000 \
  --rebalance monthly --cost-bps 10 --output outputs/my-portfolio
```

Ticker names must exist in the asset input. Omitted assets receive zero weight.
Weights are decimal fractions and must sum to one. There is no automatic
market-data downloader, brokerage connection, trading or portfolio optimizer.

An optional `--scenario /path/to/scenario.csv` supplies every future month's
macro-state values. Units and columns must match the historical macro states.
The output is a conditional what-if, not an unconditional forecast or an
estimated causal policy effect.

## Run the research checks

```sh
../venv/bin/python -m unittest discover -s tests -v
../venv/bin/python -m portfolio_forecast.cli backtest \
  --data outputs/demo/inputs --as-of 2026-08-31 \
  --paths 800 --horizons 1 6 12 --step 6 --max-origins 30 \
  --cost-bps 10 --output outputs/evaluation
```

`backtest.csv` archives every evaluation origin and outcome. The summary reports
all candidates on matched dates. Overlapping horizons are dependent; summary
means are descriptive, with no significance or winning-model claim. Using
today's chosen holdings historically is a diagnostic, not a survivorship-free
trading-strategy backtest. Synthetic backtests test the workflow only.

## Output files

| File | Contents |
|---|---|
| `report.html` | Interactive local portfolio builder and forecast display |
| `forecast.json` | Full-precision summaries, loadings, expert weights and update archive |
| `paths_0.npz`, `paths_1.npz` | Joint asset/factor/macro paths and original portfolio wealth |
| `scenario_used.csv` | Exact imposed macro path, when supplied |
| `manifest.json` | Model settings, input/source hashes, seed and library versions |
| `backtest.csv`, `backtest_summary.csv` | Per-origin distribution scores and matched summaries |
| `backtest_manifest.json` | Independent evaluation provenance |

The report embeds log returns rounded to eight decimals; archived NPZ paths are
full precision. Percentile bands are pointwise; neither an entire-path coverage
claim nor a confidence interval for an estimated mean. Holding changes do not
automatically rerun backtest calibration.

## Practical boundaries

Monthly US stock/ETF total returns, long-only, fully invested, one reporting
currency. No shorting, leverage, options, taxes, cash flows, FX translation or
default event model. Exact −100% returns and incomplete histories are rejected,
not silently dropped. Market data is assumed available at month end; macro
release times are enforced. Research defaults are fixed assumptions, not tuned
or certified settings. The next gate is vetted historical market data and a
frozen out-of-sample evaluation before expanding the model stack.
